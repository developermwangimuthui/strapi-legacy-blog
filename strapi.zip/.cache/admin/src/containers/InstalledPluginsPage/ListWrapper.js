import styled from 'styled-components';

const Wrapper = styled.div`
  padding-top: 3px;
`;

export default Wrapper;
